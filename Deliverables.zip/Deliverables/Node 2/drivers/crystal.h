/*
 * crystal.h
 *
 * Created: 06.11.2013 15:01:46
 *  Author: chriwes
 */ 


#ifndef CRYSTAL_H_
#define CRYSTAL_H_

#define F_CPU 8200000UL //8.2MHz

#endif /* CRYSTAL_H_ */