/*
 * adc.h
 *
 * Created: 11.09.2013 12:44:08
 *  Author: chriwes
 */ 


#ifndef ADC_H_
#define ADC_H_

void ADCTest();

char ADC_read(int channel); //returns filtered data from given channel

#endif /* ADC_H_ */