/*
 * SRAM.h
 *
 * Created: 04.09.2013 11:37:19
 *  Author: chriwes
 */ 


#ifndef SRAM_H_
#define SRAM_H_

void SRAM_test();
void SRAM_init();

#endif /* SRAM_H_ */